/* Demo account for the front-end back office (example configuration).
   Used by the "fill with the demo account" button on the login screen.
   Remove this file — and change the password in Équipe & rôles — before any real use. */
window.RELAXX_DEMO_LOGIN = { email: "admin@relaxx.example", pass: "Relaxx#2026" };
