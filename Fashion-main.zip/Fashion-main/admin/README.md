# Back-office RELAXX

Espace de gestion de la boutique : `admin/index.html` (par exemple `http://localhost:5173/admin/`).

## Compte de démonstration

| E-mail | Mot de passe | Rôle |
| --- | --- | --- |
| admin@relaxx.example | Relaxx#2026 | Administrateur |

Le bouton « Remplir avec le compte de démonstration » de l'écran de connexion utilise `admin/demo-login.js`.
**Avant toute mise en ligne :** supprimer `demo-login.js`, retirer sa ligne dans `admin/index.html` et changer le mot de passe (menu du profil → « Changer mon mot de passe »).

Les autres membres de l'équipe (Awa Koné — Gestionnaire, Koffi Mensah — Support, Stagiaire — Lecture seule) n'ont pas encore de mot de passe : un administrateur le définit dans **Équipe & rôles**.

## Ce que l'on gère

| Section | Contenu |
| --- | --- |
| Tableau de bord | CA, commandes, panier moyen, conversion (7/30/90 j, comparaison avec la période précédente), courbe des ventes et des visites, tâches à traiter, objectif mensuel, meilleures ventes, catégories, paiements, villes, dernières commandes |
| Rapports | Ventes par jour/semaine/mois, par produit (marge estimée), catégorie, pays/ville, moyen de paiement, codes promo — exports CSV |
| Commandes | Filtres par statut, paiement, période, recherche ; actions groupées ; fiche commande : statut (avec remise en stock en cas d'annulation/remboursement), n° de suivi, notes internes, historique, client, adresse, paiement, facture imprimable (PDF) |
| Clients | Segments (VIP, fidèles, nouveaux, inactifs, prospects), fiche client modifiable, historique, anonymisation (droit à l'oubli), export |
| Codes promo | Pourcentage, montant fixe ou livraison offerte, minimum de commande, dates, limite d'utilisation, pause — vérifiés en direct au checkout |
| Produits | Liste, filtres, création/édition en français, photo, prix, prix barré, coût d'achat et marge, étiquette, statut (actif/brouillon/archivé), aperçu, duplication, remise groupée. **Couleurs** : jusqu'à 12 par produit (nom, teinte, photo propre à la couleur, ordre), palette de couleurs courantes, stock par couleur × taille ; ou « couleur unique » avec un stock par taille |
| Stock | Quantités par couleur et par taille éditables, alertes (seuil réglable), valeur du stock, export |
| Catégories | Noms, ordre des onglets, visibilité |
| Avis clients | Modération (publier, masquer, supprimer), réponses publiques affichées sur la fiche produit, modération avant publication activable |
| Newsletter | Abonnés reçus depuis le site, courbe d'inscriptions, sources, ajout manuel, désinscription, export |
| Vitrine du site | Textes (en français), images, liens et sections affichées/masquées de la page d'accueil (bannière, catégories tendance, collection, notre histoire, avis mis en avant, accessoires, newsletter, Instagram), de la page Notre histoire et du pied de page ; produits mis en avant ; titres et descriptions Google (SEO) ; aperçu ordinateur/mobile. Seuls les contenus modifiés sont enregistrés, « Rétablir l'original » revient au texte des pages |
| Vitrine › Instagram | Galerie avant le pied de page : chaque photo ouvre sa propre publication sur Instagram. Mode automatique (compte Instagram professionnel connecté par jeton d'accès : les 5 dernières publications s'affichent, actualisation de 15 min à 24 h, publications masquables, jeton renouvelé automatiquement) ou manuel (photo choisie, importée ou par lien + lien de la publication, vérifié). Photos de secours si Instagram est injoignable |
| Médiathèque | Partout où l'on choisit une image : import depuis l'ordinateur ou le téléphone (bouton, glisser-déposer, coller), médiathèque des fichiers déjà importés (réutilisation, suppression avec alerte si le fichier est utilisé), images du site, lien. Photos redimensionnées automatiquement (2400 px max). Bannière d'accueil : image **ou vidéo** (MP4/WebM, muette, en boucle, image d'aperçu générée automatiquement, pas de lecture automatique si le visiteur a demandé moins d'animations) |
| Annonce & maintenance | Barre d'annonce (en haut de toutes les pages), mode maintenance |
| Livraison | Tarifs et délais standard/express, livraison offerte dès X FCFA, pays desservis |
| Paiements | Mobile Money (Wave, Orange Money, MTN MoMo, Moov Money), carte, paiement à la livraison (plafond), PayPal, Apple Pay |
| Réglages | Coordonnées, mentions légales (RCCM, NCC), TVA, notifications, sauvegarde/restauration JSON, suppression des données de démo, réinitialisation |
| Équipe & rôles | Membres, rôles (Administrateur, Gestionnaire, Support client, Lecture seule), matrice des permissions, mots de passe |
| Journal d'activité | Toutes les actions de l'équipe et les événements de la boutique |

**Langues** : le back-office est entièrement en français. À chaque enregistrement (produits, couleurs, catégories, vitrine, référencement, annonce), la version anglaise du site est traduite automatiquement et affichée sous le champ (« EN … ») ; seuls les textes modifiés sont retraduits.

Aussi : recherche globale (⌘K / Ctrl+K), notifications, thème clair/sombre, affichage mobile, synchronisation en direct avec la boutique ouverte dans un autre onglet (une nouvelle commande apparaît immédiatement).

## Architecture

- `relaxx-db.js` (racine du site) : couche de données partagée par la boutique et le back-office, stockée dans le `localStorage` du navigateur (clé `relaxx-db`). Au premier chargement, elle crée un jeu de démonstration réaliste (120 jours de commandes, clients, avis, abonnés, visites).
- La boutique lit : catalogue, prix, stock, statut des produits, catégories visibles, traductions, codes promo, livraison, paiements, pays, barre d'annonce, maintenance, vitrine, galerie Instagram.
- La boutique écrit : commandes (checkout), avis (fiche produit), inscriptions newsletter (accueil), visites.
- Médiathèque : les fichiers importés sont stockés dans IndexedDB (`relaxx-media`) et notés `media:<id>.<ext>` dans les données ; `sw.js` (service worker à la racine) les sert à l'adresse `media/<id>.<ext>` comme des fichiers normaux (lecture partielle des vidéos comprise). Ils ne font pas partie de la sauvegarde JSON des Réglages.
- Variantes : `p.colors` (liste des couleurs) et `p.vstock` (stock par couleur puis par taille) ; `p.stock` reste le total par taille, recalculé automatiquement. Une commande retire le stock de la couleur et de la taille achetées ; une annulation avec remise en stock le rend au même endroit.
- `admin/translate.js` : traduction automatique français → anglais au moment de l'enregistrement (Google Translate, repli MyMemory), avec cache. Sans connexion, le texte français est gardé et la traduction refaite au prochain enregistrement.
- `admin/core.js` : connexion, rôles, navigation, composants, graphiques. `admin/views-*.js` : les écrans.

## Passage en production (à prévoir)

Cette version fonctionne entièrement dans le navigateur : les données sont propres à chaque appareil et la connexion n'est pas une vraie sécurité. Pour une boutique réelle :

1. Remplacer `relaxx-db.js` par une API serveur (base de données, authentification, sessions, droits vérifiés côté serveur) — les fonctions (`placeOrder`, `checkPromo`, `addReview`, `subscribe`…) correspondent une à une à des routes d'API.
2. Brancher un prestataire de paiement agréé (CinetPay, PayDunya, Stripe, API Wave / Orange Money).
3. Instagram : déplacer le jeton d'accès et la synchronisation côté serveur (tâche planifiée qui interroge `graph.instagram.com/me/media` et renouvelle le jeton via `refresh_access_token`), le site ne lisant plus qu'une liste de publications en cache. Dans cette version le jeton reste dans le navigateur de l'administrateur.
4. Médiathèque : envoyer les fichiers sur le serveur ou un CDN (qui génère aussi les différentes tailles d'image) au lieu du stockage du navigateur ; `sw.js` devient alors inutile.
5. Traduction : passer par une API officielle côté serveur (DeepL ou Google Cloud Translation, avec la clé de la boutique) au lieu du service public utilisé par cette démo.
6. Brancher un service d'e-mails (confirmations de commande, notifications, newsletter).
7. Supprimer le compte et les données de démonstration.
